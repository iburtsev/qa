CREATE TABLE IF NOT EXISTS customer_entity
(
    id integer AUTO_INCREMENT PRIMARY KEY,
    nick_name varchar(255) DEFAULT NULL,
    login varchar(255) DEFAULT NULL,
    password varchar(255) DEFAULT NULL,
    token varchar(255) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS phone_entity
(
    id integer AUTO_INCREMENT PRIMARY KEY,
    label varchar(255) DEFAULT NULL,
    description varchar(255) DEFAULT NULL,
    available boolean DEFAULT TRUE,
    book_time TIMESTAMP DEFAULT NULL,
    booker_nick_name varchar(255) DEFAULT NULL
);
