INSERT INTO customer_entity ( id, login, password, nick_name, token ) VALUES ( 1, 'login1', 'pass1', 'jonny', 'QWERTY12323434JJJJ');
INSERT INTO customer_entity ( id, login, password, nick_name, token ) VALUES ( 2, 'login2', 'pass2', 'billy', 'QWEfsg662323434JJM');
INSERT INTO customer_entity ( id, login, password, nick_name, token ) VALUES ( 3, 'login3', 'pass3', 'annak', '45423434JJJJOOOOOO');
