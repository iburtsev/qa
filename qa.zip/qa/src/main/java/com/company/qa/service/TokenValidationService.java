package com.company.qa.service;

import com.company.qa.entity.CustomerEntity;

public interface TokenValidationService {

    CustomerEntity validate(String token);
}
