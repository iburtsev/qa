package com.company.qa.service;

import com.company.qa.model.Customer;
import java.util.Optional;

public interface CustomerAuthorizationService {

    Optional<Customer> getUser(String login, String password);
    Optional<Customer> findByToken(String token);
}
