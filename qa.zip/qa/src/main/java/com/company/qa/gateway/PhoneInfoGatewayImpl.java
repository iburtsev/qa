package com.company.qa.gateway;

import com.company.qa.gateway.model.Cellular;
import com.company.qa.gateway.model.Inside;
import com.company.qa.gateway.model.Item;
import com.company.qa.gateway.model.Product;
import com.company.qa.gateway.model.TechItem;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PhoneInfoGatewayImpl implements PhoneInfoGateway{

    private RestTemplate restTemplate;
    private Environment environment;
    private ObjectMapper mapper;

    private final String BASE_URL = "https://api.techspecs.io/v4/product/";
    private final String productByIdUrl = BASE_URL + "search?query=";
    private final String productInfoByIdUrl = BASE_URL + "detail?productId=";

    @Autowired
    public PhoneInfoGatewayImpl(RestTemplate restTemplate, Environment environment, ObjectMapper mapper){
        this.restTemplate = restTemplate;
        this.environment = environment;
        this.mapper = mapper;
    }

    public Optional<String> getProductIdByName(String description){
        String resourceUrl = productByIdUrl + encodeValue(description);

        ResponseEntity<String> response = restTemplate.exchange(resourceUrl,
                                        HttpMethod.POST,
                                        wrapRequest(null,
                                        environment.getProperty( "techspecs.bearer.auth" )), String.class);

        try {
            Map<String, Object> result = mapper.readValue( response.getBody(), Map.class );
            Integer status = (Integer) result.get( "status" );
            if( HttpStatus.OK.value() == status.intValue() ){
                Map<String, Object> dataJson = (Map<String, Object>)result.get( "data" );
                List<Map<String, Object>> items = (List<Map<String, Object>>) dataJson.get( "items" );
                Optional<String> found = items.stream().filter( i -> {
                    Product product = mapper.convertValue( i.get( "product" ), Product.class);
                    String model = product.getModel();
                    return model.equals( description );
                } ).map( it -> {
                    Product product = mapper.convertValue( it.get( "product" ), Product.class);
                    return product.getId();
                }).findFirst();
                return found;
            }
        } catch ( JsonProcessingException exception ){
            return Optional.empty();
        }
        return Optional.empty();
    }

    public Optional<Cellular> getProductInfoById(String productId){
        String resourceUrl = productInfoByIdUrl + productId;

        ResponseEntity<String> response
                = restTemplate.exchange(resourceUrl,
                                        HttpMethod.GET,
                                        wrapRequest(null,
                                        environment.getProperty( "techspecs.bearer.auth" )), String.class);

        try {
            Map<String, Object> result = mapper.readValue( response.getBody(), Map.class );
            Integer status = (Integer) result.get( "status" );
            if( HttpStatus.OK.value() == status.intValue()  ){
                Map<String, Object> dataJson = (Map<String, Object>)result.get( "data" );
                List<Map<String, Object>> items = (List<Map<String, Object>>) dataJson.get( "items" );
                Optional<Cellular> found = items.stream().filter( i -> {
                    Product product = mapper.convertValue( i.get( "product" ), Product.class);
                    String id = product.getId();
                    return id.equals( productId );
                } ).map( it -> {
                    Inside inside = mapper.convertValue( it.get( "inside" ), Inside.class);
                    return inside.getCellular();
                } ).findFirst();
                return found;
            }
        } catch ( JsonProcessingException exception ){
            return Optional.empty();
        }
        return Optional.empty();
    }

    private HttpEntity<Object> wrapRequest(Object request, String encodedCredentials){
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept( Collections.singletonList( MediaType.APPLICATION_JSON ) );
        headers.setContentType( MediaType.APPLICATION_JSON );
        headers.setBearerAuth( encodedCredentials );
        return new HttpEntity<>( request, headers );
    }

    private String encodeValue(String value) {
        String encoded = "";
        try {
            encoded = URLEncoder.encode( value, StandardCharsets.UTF_8.toString() );
        } catch(UnsupportedEncodingException exception){
            //We do not expect it happens here
        }
        return encoded;
    }

}
