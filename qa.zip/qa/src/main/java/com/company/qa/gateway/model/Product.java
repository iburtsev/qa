package com.company.qa.gateway.model;

import lombok.Data;

@Data
public class Product {
    private String id;
    private String model;
}
