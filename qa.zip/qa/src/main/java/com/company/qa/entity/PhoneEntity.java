package com.company.qa.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.springframework.data.annotation.Id;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class PhoneEntity {

    @Column
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column
    private String label;

    @Column
    private String description;

    @Column
    private boolean available;

    @Column(name = "book_time")
    private LocalDateTime bookTime;

    @Column(name = "booker_nick_name")
    private String bookerNickName;

}
