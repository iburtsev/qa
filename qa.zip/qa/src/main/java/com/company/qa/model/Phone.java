package com.company.qa.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Phone {

    private Integer id;
    private String label;
    private String description;
    private boolean available;
    private LocalDateTime bookTime;
    private String bookerNickName;

    private String technology;
    private String bands2g;
    private String bands3g;
    private String bands4g;
}
