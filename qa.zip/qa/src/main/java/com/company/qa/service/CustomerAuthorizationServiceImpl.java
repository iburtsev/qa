package com.company.qa.service;

import com.company.qa.entity.CustomerEntity;
import com.company.qa.model.Customer;
import com.company.qa.repository.CustomerRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerAuthorizationServiceImpl implements CustomerAuthorizationService {

    private final CustomerRepository repository;

    @Autowired
    public CustomerAuthorizationServiceImpl(CustomerRepository repository){
        this.repository = repository;
    }

    @Override
    public Optional<Customer> getUser(String login, String password) {
        Optional<CustomerEntity> customer = repository.findByLoginAndPassword( login, password );
        return mapResult( customer );
    }

    @Override
    public Optional<Customer> findByToken(String token) {
        Optional<CustomerEntity> customer = repository.findByToken( token );
        return mapResult( customer );
    }

    private Optional<Customer> mapResult(Optional<CustomerEntity> customer) {
        if ( customer.isPresent() ) {
            CustomerEntity ce = customer.get();
            return Optional.of( Customer.builder().nickName( ce.getNickName() ).token( ce.getToken() ).build() );
        }
        return Optional.empty();
    }
}
