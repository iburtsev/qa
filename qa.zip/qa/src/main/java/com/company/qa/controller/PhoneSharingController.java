package com.company.qa.controller;

import com.company.qa.entity.CustomerEntity;
import com.company.qa.model.Booking;
import com.company.qa.model.Criteria;
import com.company.qa.model.Phone;
import com.company.qa.model.Phones;
import com.company.qa.service.PhoneSharingService;
import com.company.qa.service.TokenValidationService;
import java.security.InvalidParameterException;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/phones")
public class PhoneSharingController {

    private PhoneSharingService service;
    private TokenValidationService validator;

    public PhoneSharingController(PhoneSharingService service, TokenValidationService validator){
        this.service = service;
        this.validator = validator;
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public Phones getAllDevices(@RequestBody Criteria criteria, @NotBlank @RequestParam String token){
        validator.validate( token );
        return service.getAllDevices(criteria);
    }

    @GetMapping(value = "/{deviceId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Phone getDeviceInfo(@PathVariable Integer deviceId, @NotBlank @RequestParam String token){
        validator.validate( token );
        return service.getDeviceInfo(deviceId).orElseThrow(() -> new InvalidParameterException("Device does not exist.") );
    }

    @GetMapping(value = "/full/{deviceId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Phone getFullDeviceInfo(@PathVariable Integer deviceId, @NotBlank @RequestParam String token){
        validator.validate( token );
        return service.getFullDeviceInfo(deviceId).orElseThrow(() -> new InvalidParameterException("Device does not exist.") );
    }

    @PostMapping(value ="/{deviceId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Booking bookDevice(@PathVariable Integer deviceId, @NotNull @RequestParam Boolean toBook, @NotBlank @RequestParam String token){
        CustomerEntity user = validator.validate( token );
        return service.bookDevice(deviceId, toBook, user.getNickName());
    }

}
