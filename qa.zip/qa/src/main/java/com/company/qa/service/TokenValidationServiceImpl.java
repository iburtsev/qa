package com.company.qa.service;

import com.company.qa.entity.CustomerEntity;
import com.company.qa.repository.CustomerRepository;
import java.security.InvalidParameterException;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TokenValidationServiceImpl implements TokenValidationService {

    private CustomerRepository repository;

    @Autowired
    public TokenValidationServiceImpl(CustomerRepository repository){
        this.repository = repository;
    }

    @Override
    public CustomerEntity validate(String token) {
        Optional<CustomerEntity> user = repository.findByToken(token);
        if(user.isEmpty()){
            throw new InvalidParameterException("User does not exist.");
        }
        return user.get();
    }
}
