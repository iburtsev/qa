package com.company.qa.service;

import com.company.qa.model.Booking;
import com.company.qa.model.Criteria;
import com.company.qa.model.Phone;
import com.company.qa.model.Phones;
import java.util.Optional;

public interface PhoneSharingService {

    Phones getAllDevices(Criteria criteria);

    Optional<Phone> getDeviceInfo(Integer deviceId);

    Optional<Phone> getFullDeviceInfo(Integer deviceId);

    Booking bookDevice(Integer deviceId, boolean toBook, String nickName);
}
