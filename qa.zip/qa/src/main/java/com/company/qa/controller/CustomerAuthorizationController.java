package com.company.qa.controller;

import com.company.qa.model.Customer;
import com.company.qa.service.CustomerAuthorizationService;
import java.security.InvalidParameterException;
import java.util.Optional;
import javax.validation.constraints.NotBlank;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class CustomerAuthorizationController {

    private CustomerAuthorizationService service;

    public CustomerAuthorizationController(CustomerAuthorizationService service){
        this.service = service;
    }

    @GetMapping(value = "/token", produces = MediaType.APPLICATION_JSON_VALUE)
    public Customer getToken(@NotBlank @RequestParam String login, @NotBlank @RequestParam String password){
        Optional<Customer> customer = service.getUser(login, password);
        return customer.get();//orElseGet( () -> Customer.builder().build() );
    }

}
