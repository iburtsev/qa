package com.company.qa.gateway.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class Cellular {

    @JsonProperty("sim_frequencies")
    private String simFrequencies;

    private String generation;
}
