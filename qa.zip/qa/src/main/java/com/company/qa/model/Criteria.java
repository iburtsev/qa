package com.company.qa.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Criteria {

    private static final int DEFAULT_PAGE_INDEX = 0;
    private static final int DEFAULT_PAGE_SIZE = 20;

    private int page = DEFAULT_PAGE_INDEX;
    private int perPage = DEFAULT_PAGE_SIZE;
    private boolean available;
    private String label;
    private String bookerNickName;
}
