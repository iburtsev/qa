package com.company.qa.gateway;

import com.company.qa.gateway.model.Cellular;
import com.company.qa.gateway.model.Item;
import com.company.qa.gateway.model.TechItem;
import java.util.List;
import java.util.Optional;

public interface PhoneInfoGateway {

    Optional<String> getProductIdByName(String description);
    Optional<Cellular> getProductInfoById(String productId);
}
