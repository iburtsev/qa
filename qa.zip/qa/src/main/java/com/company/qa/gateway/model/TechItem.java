package com.company.qa.gateway.model;

import lombok.Data;

@Data
public class TechItem {

    private Product product;
    private Inside inside;
}
