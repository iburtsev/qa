package com.company.qa.repository;

import com.company.qa.entity.CustomerEntity;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<CustomerEntity, Integer> {

    Optional<CustomerEntity> findByToken(String token);
    Optional<CustomerEntity> findByLoginAndPassword(String login, String password);
}
