package com.company.qa.service;

import com.company.qa.entity.PhoneEntity;
import com.company.qa.gateway.PhoneInfoGateway;
import com.company.qa.gateway.model.Cellular;
import com.company.qa.gateway.model.Item;
import com.company.qa.gateway.model.Product;
import com.company.qa.gateway.model.TechItem;
import com.company.qa.model.Booking;
import com.company.qa.model.Criteria;
import com.company.qa.model.Phone;
import com.company.qa.model.Phones;
import com.company.qa.repository.PhoneRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Service
public class PhoneSharingServiceImpl implements PhoneSharingService{

    private PhoneRepository repository;
    private PhoneInfoGateway phoneGateway;

    @Autowired
    public PhoneSharingServiceImpl(PhoneRepository repository, PhoneInfoGateway phoneGateway){
        this.repository = repository;
        this.phoneGateway = phoneGateway;
    }

    @Override
    public Phones getAllDevices(Criteria criteria) {
        PageRequest pr = PageRequest.of( criteria.getPage(), criteria.getPerPage() );
        Page<PhoneEntity> entities = repository.findByAvailableOrLabelOrBookerNickName( criteria.isAvailable(),
                                                                                        criteria.getLabel(),
                                                                                        criteria.getBookerNickName(),
                                                                                        pr);
        return Phones.builder().phones( entities.get().map( p -> mapToPhone( p ) ).collect( Collectors.toList() ) ).build();
    }

    @Override
    public Optional<Phone> getDeviceInfo(Integer id) {
        Optional<PhoneEntity> entity = repository.findById( id );
        if(entity.isPresent()){
            PhoneEntity pe = entity.get();
            return Optional.of( mapToPhone(pe) );
        }
        return Optional.empty();
    }

    @Override
    public Optional<Phone> getFullDeviceInfo(Integer deviceId) {
        Optional<PhoneEntity> entity = repository.findById( deviceId );
        if(entity.isPresent()){
            PhoneEntity pe = entity.get();
            Phone phone = mapToPhone(pe) ;
            Optional<String> foundId = phoneGateway.getProductIdByName( phone.getDescription() );

            if(foundId.isPresent()) {
                String id = foundId.get();
                Optional<Cellular> cellularOptional = phoneGateway.getProductInfoById(id);
                if(cellularOptional.isPresent()){
                    Cellular cellular = cellularOptional.get();
                    phone.setTechnology( cellular.getGeneration() );
                    enrichPhoneBands(phone, cellular);
                }
            }
            return Optional.of( phone );
        }
        return Optional.empty();
    }

    @Override
    public Booking bookDevice(Integer deviceId, boolean toBook, String nickName) {
        Optional<PhoneEntity> entity = repository.findById( deviceId );
        Booking.BookingBuilder booking = Booking.builder();
        if(entity.isPresent()){
            PhoneEntity pe = entity.get();
            if(toBook && !pe.isAvailable()){
                if(nickName.equals( pe.getBookerNickName() )){
                    return booking.success( true ).phone( mapToPhone( pe ) ).build();
                }
                return booking.success( false ).phone( mapToPhone( pe ) ).build();
            } else if(toBook && pe.isAvailable()){
                pe.setAvailable( false );
                pe.setBookerNickName( nickName );
                pe.setBookTime( LocalDateTime.now() );
                pe = repository.save( pe );
                return booking.success( true ).phone( mapToPhone( pe ) ).build();
            } else if(!toBook && !pe.isAvailable()){
                pe.setAvailable( true );
                pe.setBookerNickName( null );
                pe.setBookTime( null );
                pe = repository.save( pe );
                return booking.success( true ).phone( mapToPhone( pe ) ).build();
            }
        }
        return booking.success( false ).build();
    }

    private void enrichPhoneBands(Phone phone, Cellular cellular){
        String bands2g = extractBands( cellular, Arrays.asList("Band II", "Band 2") );
        String bands3g = extractBands( cellular, Arrays.asList("Band III", "Band 3" ) );
        String bands4g = extractBands( cellular, Arrays.asList("Band IV", "Band 4" ) );
        phone.setBands2g( bands2g );
        phone.setBands3g( bands3g );
        phone.setBands4g( bands4g );
    }

    private String extractBands(Cellular cellular, List<String> examples) {
        String bands = Arrays.asList( cellular.getSimFrequencies().split( ", " )).stream().filter( f -> f.contains( examples.get( 0 ) )
                || f.contains( examples.get( 1 ) )).collect( Collectors.joining( ",", "|", "|"));
        return bands;
    }

    private Phone mapToPhone(PhoneEntity entity){
        return Phone.builder()
                    .id( entity.getId() )
                    .label( entity.getLabel() )
                    .description( entity.getDescription() )
                    .bookerNickName( entity.getBookerNickName() )
                    .available( entity.isAvailable() )
                    .bookTime( entity.getBookTime() )
                    .build();
    }
}
