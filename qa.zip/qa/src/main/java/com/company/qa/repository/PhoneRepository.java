package com.company.qa.repository;

import com.company.qa.entity.PhoneEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface PhoneRepository extends PagingAndSortingRepository<PhoneEntity, Integer> {

    Page<PhoneEntity> findByAvailableOrLabelOrBookerNickName(boolean available, String label, String bookerNickName, Pageable pageable);
}
