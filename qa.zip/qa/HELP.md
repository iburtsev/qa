# Getting Started

1. Get access token by calling http get on http://localhost:8080/users/token?login=login1&password=pass1
2. Get all accessible phones by calling hhtp get on http://localhost:8080/phones?token=QWERTY12323434JJJJ 
    with body example:
    {
        "page": 0,
        "perPage":20,
        "available":true,
        "label":"AIP_13_1",
        "bookerNickName":"jonny"
    }
3. Try to book some device :

    http://localhost:8080/phones/6?token=QWERTY12323434JJJJ&toBook=true
    
    here you could try to book device with id 6.
    
4. Get rich information from external system:
   
   http://localhost:8080/phones/full/6?token=QWERTY12323434JJJJ
   
   here you will get full information with data from third-party service

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.7.11/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.7.11/maven-plugin/reference/html/#build-image)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/2.7.11/reference/htmlsingle/#using.devtools)
* [Flyway Migration](https://docs.spring.io/spring-boot/docs/2.7.11/reference/htmlsingle/#howto.data-initialization.migration-tool.flyway)
* [Spring Data JDBC](https://docs.spring.io/spring-boot/docs/2.7.11/reference/htmlsingle/#data.sql.jdbc)
* [Spring Boot Actuator](https://docs.spring.io/spring-boot/docs/2.7.11/reference/htmlsingle/#actuator)

### Guides
The following guides illustrate how to use some features concretely:

* [Using Spring Data JDBC](https://github.com/spring-projects/spring-data-examples/tree/master/jdbc/basics)
* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)

